class Simple {
	public static void main(String[] a) {
	    int x;

        x = 10;

	    System.out.println(x);
	}
}
