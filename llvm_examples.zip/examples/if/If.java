class Simple {
	public static void main(String[] a) {
	    int x;

        x = 10;

        if (x < 2)
	        System.out.println(0);
	    else
	        System.out.println(1);
	}
}
