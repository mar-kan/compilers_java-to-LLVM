class BooleanArrays {
    public static void main(String[] a) {
        boolean[] b;
        b = new boolean[10];

        b[0] = true;

        if (b[1]) {
            System.out.println(1);
        }
        else {
            System.out.println(2);
        }
    }
}